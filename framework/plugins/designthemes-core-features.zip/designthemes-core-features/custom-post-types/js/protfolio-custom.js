jQuery.noConflict();
jQuery(document).ready(function($){

	if( $(".dt-gallery-single-slider").find("li").length > 1 ) {
		$(".dt-gallery-single-slider").bxSlider({ auto:false, video:true, useCSS:false, pagerCustom: '#bx-pager', autoHover:true, adaptiveHeight:true, controls:true });
	}

	var $pphoto = $('a[data-gal^="prettyPhoto[gallery]"]');
	if ($pphoto.length) {
		$pphoto.prettyPhoto({
			hook: 'data-gal',
			show_title: false,
			deeplinking: false,
			social_tools: false,
			default_width: 500,
			default_height: 344
       });
	}


	$(window).bind("resize", function() {

		if( $('.dt-sc-gallery-container').length ) {
			$('.dt-sc-gallery-container').css({overflow:'hidden'}).isotope({itemSelector : '.column',masonry: { columnWidth: '.grid-sizer' } });
		}

	});	

	$(window).on('load', function(){

		var galleryHeight = $('.dt-sc-gallery-wrapper .gallery:first').height();
		$('.icon-link-title').css('height', galleryHeight+'px');	

		//Gallery Template : Sorting
		var $container = $('.dt-sc-gallery-container');
		if( $container.length) {

			$container.isotope({
				filter: '*',
				masonry: { columnWidth: '.grid-sizer' },
				animationOptions: { duration: 750, easing: 'linear', queue: false  }
			});
		}//Isotope End

		if($("div.dt-sc-gallery-sorting").length){

			$("div.dt-sc-gallery-sorting a").on('click',function(){
				$("div.dt-sc-gallery-sorting a").removeClass("active-sort");

				var selector = $(this).attr('data-filter');
				$(this).addClass("active-sort");

				$('.dt-sc-gallery-container').isotope({
					filter: selector,
					masonry: { columnWidth: '.grid-sizer' },
					animationOptions: { duration:750, easing: 'linear',  queue: false }
				});

				return false;
			});
		} //Gallery Template : Sorting End

	});	


	/* Load More Button */
	$('.dt-sc-infinite-gallery-load-more').each(function(){

		var $this = $(this),
			$x = $(this).prev('.dt-sc-infinite-gallery-container').data('paged'),
			$xstyle = $(this).data('style');

		if(  $xstyle == 'lazy' ) {
			$(window).scroll(function(){
				if($(window).scrollTop() == $(document).height() - $(window).height()){

					var $per_page = $this.data('per-page'),
						$term = $this.data('term'),
						$style = $this.data('style'),
						$paged = $x,
						$prev = $this.prev();

					$x++;

					$.ajax({
						type : "post",
						dataType : "html",
						url : dttheme_urls.ajaxurl,
						data : { action: "dt_ajax_infinite_galleries", per_page : $per_page, term : $term, style: $style , paged: $paged },
						success: function (data) {
							if (data.length > 0) {
								$prev.append( data );
							} else {
								$prev.find(".message").removeClass("hidden");
								//$this.addClass('hidden');

								setTimeout(function(){
									$prev.find(".message").addClass('hidden');
									$this.addClass('disable');									
								}, 5000);								
							}
						},
						error: function (jqXHR, textStatus, errorThrown) {
						}
					});				
				}
			});
		} else if( $xstyle == 'load-more') {

			$this.on('click', function(e){

				e.preventDefault();

				var $per_page = $(this).data('per-page'),
					$term = $(this).data('term'),
					$style = $(this).data('style'),
					$paged = $x,
					$prev = $(this).prev();

				$x++;

				$.ajax({
					type : "post",
					dataType : "html",
					url : dttheme_urls.ajaxurl,
					data : { action: "dt_ajax_infinite_galleries", per_page : $per_page, term : $term, style: $style , paged: $paged },
					success: function (data) {

						if (data.length > 0) {
							$prev.append( data );
						} else {
							$prev.find(".message").removeClass("hidden");
							//$this.addClass('hidden');

							setTimeout(function(){
								$prev.find(".message").addClass('hidden');
								$this.addClass('disable');
							}, 5000);
						}
					},
					error: function (jqXHR, textStatus, errorThrown) {
					}
				});
			});
		}
	});


});