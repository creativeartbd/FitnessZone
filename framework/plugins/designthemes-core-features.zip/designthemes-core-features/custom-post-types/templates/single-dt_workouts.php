<?php get_header();
	$settings = get_post_meta ( $post->ID, '_workout_settings', TRUE );
	$settings = is_array ( $settings ) ? $settings : array ();
	global $dt_allowed_html_tags;
    $global_breadcrumb = cs_get_option( 'show-breadcrumb' );

    $header_class = '';
    if( !$settings['enable-sub-title'] || !isset( $settings['enable-sub-title'] ) ) {
        if( isset( $settings['show_slider'] ) && $settings['show_slider'] ) {
            if( isset( $settings['slider_type'] ) ) {
                $header_class =  $settings['slider_position'];
            }
        }
    }
    
    if( !empty( $global_breadcrumb ) ) {
        if( isset( $settings['enable-sub-title'] ) && $settings['enable-sub-title'] ) {
            $header_class = $settings['breadcrumb_position'];
		}
	}?>

<!-- ** Header Wrapper ** -->
<div id="header-wrapper"  class="<?php echo esc_attr($header_class); ?>">
    <!-- **Header** -->
    <header id="header">

        <div class="container"><?php
            /**
             * fitnesszone_header hook.
             * 
             * @hooked fitnesszone_vc_header_template - 10
             *
             */
            do_action( 'fitnesszone_header' ); ?>
        </div>
    </header><!-- **Header - End ** -->

    <!-- ** Breadcrumb ** -->
    <?php
        # Global Breadcrumb
        if( !empty( $global_breadcrumb ) ) {
            if( isset( $settings['enable-sub-title'] ) && $settings['enable-sub-title'] ) {
                $breadcrumbs = array();
                $bstyle = fitnesszone_cs_get_option( 'breadcrumb-style', 'default' );

                $cat = get_the_term_list( $post->ID, 'workout_entries', '', '$$$', '');
                $cats = array_filter(explode('$$$', $cat));
                if (!empty($cats))
                	$breadcrumbs[] = $cats[0];

                $breadcrumbs[] = the_title( '<span class="current">', '</span>', false );
				$style = fitnesszone_breadcrumb_css( $settings['breadcrumb_background'] );
				$title = '<h1>'.esc_attr('Workout Plan', 'designthemes-core').'</h1>';
				
				$sub_title = $settings['sub-title'];
                fitnesszone_breadcrumb_output ( $title, $breadcrumbs, $bstyle, $style, $sub_title );
            }
        }
    ?><!-- ** Breadcrumb End ** -->                
</div><!-- ** Header Wrapper - End ** -->

<!-- **Main** -->
<div id="main">

    <!-- ** Container ** -->
    <div class="container"><?php
        $page_layout  = array_key_exists( "layout", $settings ) ? $settings['layout'] : "content-full-width";
        $layout = fitnesszone_page_layout( $page_layout );
		extract( $layout );
		
		$feature_image = "fitnesszone-blog-iii-column";

	  #Better image size...
	  switch($page_layout) {
		  case "content-full-width":
			  $feature_image = "fitnesszone-gallery-ii-column";
			  break;
	  }
        ?>

        <!-- Primary -->
        <section id="primary" class="<?php echo esc_attr( $page_layout );?>"><?php
            if( have_posts() ) {
                while( have_posts() ) {
                    the_post();?>
					<article id="post-<?php the_ID();?>" <?php post_class(array('dt-workout-single'));?>>
                      <div class="dt-sc-workout-detail">
                          <div class="dt-excersise-title title"><?php
								$wmeta = get_post_meta(get_the_id(), '_workout_settings', true);
							  if(!empty($wmeta['nosteps'])): ?>
                                  <p class="count">
                                      <a href="javascript:void(0)"><?php echo wp_kses($wmeta['nosteps'], $dt_allowed_html_tags); ?> <br><span><?php _e('Steps', 'designthemes-core'); ?></span></a>
                                  </p><?php
							  endif; ?>
                              <h5><?php the_title(); ?></h5>
                          </div>
                          <div class="dt-sc-hr-invisible-small"></div>
                          <div class="dt-sc-one-half column first">
                              <div class="dt-excersise-thumb"><?php
								  $item = isset( $wmeta['feature_video'] ) ? $wmeta['feature_video'] : '';
								  if(!empty($item)):
									  #For vimeo...
									  if (strpos($item, "vimeo")) :
										  $url = substr( strrchr($item, "/"),1);
										  echo "<iframe src='https://player.vimeo.com/video/{$url}' width='100%' height='250' frameborder='0'></iframe>";
		  
									  #For youtube...
									  elseif(strpos($item, "?v=")):
										  $url = substr( strrchr($item, "="),1);
										  echo "<iframe src='https://www.youtube.com/embed/{$url}?wmode=opaque' width='100%' height='250' frameborder='0'></iframe>";
									  endif;
								  else:
									  if(has_post_thumbnail()):
										  $attr = array('title' => get_the_title(), 'alt' => get_the_title());
										  the_post_thumbnail($feature_image, $attr);
									  else: ?>
										  <img src="http<?php fitnesszone_ssl(true);?>://placehold.it/1170X800.jpg&text=<?php the_title(); ?>" alt="<?php the_title(); ?>" /><?php
									  endif;
								  endif; ?>
                              </div>
                          </div>
                          <div class="dt-sc-one-half column">
                              <div class="dt-excersise-detail"><?php
							  		$wmeta_subtitle = isset($wmeta['subtitle']) ? $wmeta['subtitle']:'';
							  	  if(!empty($wmeta_subtitle)) ?>
	                                  <h4><a href="javascript:void(0)"><?php echo wp_kses($wmeta_subtitle, $dt_allowed_html_tags); ?></a></h4><?php
								  if(!empty($wmeta['muscle_group'])) ?>
									  <h6><?php _e('Muscle Group:', 'designthemes-core'); ?></h6><p class="dt-excersise-meta"><?php echo wp_kses($wmeta['muscle_group'], $dt_allowed_html_tags); ?></p>									  

                                  <h6><?php _e('Categories:', 'designthemes-core'); ?></h6>
                                  <p class="dt-excersise-meta"><?php echo get_the_term_list($post->ID, 'workout_entries', ' ', ', ', ' '); ?></p><?php

								  if(!empty($wmeta['equipment'])) ?>
									  <h6><?php _e('Equipment:', 'designthemes-core'); ?></h6><p class="dt-excersise-meta"><?php echo wp_kses($wmeta['equipment'], $dt_allowed_html_tags); ?></p>
                              </div>
                          </div>
                          <div class="dt-sc-hr-invisible"></div>
                          <div class="dt-sc-clear"></div>
                      </div><?php
					  the_content();
                      wp_link_pages(array('before' => '<div class="page-link"><strong>'.__('Pages:', 'designthemes-core').'</strong> ', 'after' => '</div>', 'next_or_number' => 'number'));
                      edit_post_link(__('Edit', 'designthemes-core'), '<span class="edit-link">', '</span>' ); ?>
                      <div class="dt-sc-hr-invisible"></div>
                      <div class="dt-sc-clear"></div>

					  <h3 class="border-title"> <span> <?php _e('Photo Gallery', 'designthemes-core'); ?> </span></h3>
						<div class="dt-gallery-single-slider-wrapper">
							<!-- Slider -->
                            <ul class="dt-gallery-single-slider"><?php
                            	if( array_key_exists("workout-gallery",$settings) ) {
                            		$items = explode(',', $settings["workout-gallery"]);
                            		foreach( $items as $item ){
                            			echo '<li>'.wp_get_attachment_image( $item, 'full' ).'</li>';
									}
								}
								
								if( array_key_exists("workout-video",$settings) && $settings["workout-video"]!='' ) {
									
									$workout_video_final = array();
									foreach($settings["workout-video"] as $workout_video_array)
									{
										foreach($workout_video_array as $workout_video_val)	
										{
											array_push($workout_video_final, $workout_video_val);
										}    
									}
									
									foreach ( $workout_video_final as $workout_video_url ) {
									echo '<li>';
										if (strpos($workout_video_url, "vimeo")) :
											$url = substr( strrchr($workout_video_url, "/"),1);
											echo "<iframe src='http".fitnesszone_ssl()."://player.vimeo.com/video/{$url}' width='1170' height='700' frameborder='0'></iframe>";
										elseif(strpos($workout_video_url, "?v=")):
											$url = substr( strrchr($workout_video_url, "="),1);
											echo "<iframe src='http".fitnesszone_ssl()."://www.youtube.com/embed/{$url}?wmode=opaque' width='1170' height='700' frameborder='0'></iframe>";
										endif;
									echo '</li>';
									}
									
								}
								
								?>
                            </ul><!-- Slider Ends -->
                            
                            <?php if( array_key_exists("workout-gallery",$settings) && $settings["workout-gallery"]!='' ) { ?>
                            	<!-- Pager -->
                            	<div id="bx-pager"><?php
	                            	
	                            	if( array_key_exists("workout-gallery",$settings) ) {

	                            		$items = explode(',', $settings["workout-gallery"]);
	                            		$i = 0;

	                            		foreach( $items as $item ) {
	                            			echo "<a data-slide-index='".esc_attr($i)."' href=''>";
	                            				echo wp_get_attachment_image( $item, 'fitnesszone-workout-footer-widget' );
											echo "</a>";
											$i = $i + 1;
										}
									}?>
								
							<?php } 
							if( array_key_exists("workout-video",$settings) && $settings["workout-video"]!='' ) {
								$workout_video_final = array();
									foreach($settings["workout-video"] as $workout_video_array)
									{
										foreach($workout_video_array as $workout_video_val)	
										{
											array_push($workout_video_final, $workout_video_val);
										}    
									}
									$j = $i+1;
									foreach ( $workout_video_final as $workout_video_url ) {
										if (strpos($workout_video_url, "vimeo")) :
											$url = substr( strrchr($workout_video_url, "/"),1);
											echo "<a data-slide-index='".$j."' href=''><img src='".fitnesszone_getVimeoThumb($url)."' alt=".__('Vimeo Video','designthemes-core')." /></a>";													
										elseif(strpos($workout_video_url, "?v=")):
											$url = substr( strrchr($workout_video_url, "="),1);
											echo "<a data-slide-index='".$j."' href=''><img src='http".fitnesszone_ssl()."://img.youtube.com/vi/{$url}/0.jpg' alt=".__('Youtube Video','designthemes-core')." /></a>";
										endif;
									$j += 1;
									}
							}
							
							?>
                            </div><!-- Pager Ends -->
                            
						</div>

						<?php echo !empty( $container_middle ) ? $container_middle : '';?>

                        <div class="dt-portfolio-single-details">
                            <div class="column dt-sc-one-column"><?php
                            	if( array_key_exists('workout_opt_flds', $settings) ): ?>
                            		<h3><?php esc_html_e('Project Details','designthemes-core');?></h3>
                            		<ul class="project-details"><?php
                            			for( $i = 1; $i <= sizeof($settings['workout_opt_flds']) / 2; $i++ ):

                            				$label = $settings['workout_opt_flds']["workout_opt_flds_title_{$i}"];
                            				$value = $settings['workout_opt_flds']["workout_opt_flds_value_{$i}"];
											if(isset($value) && $value!=''){
												if( filter_var($value ,FILTER_VALIDATE_URL) ){
													$value = "<a href='".esc_url($value)."'>".esc_html($value)."</a>";
												} elseif( is_email($value) ){
													$email = sanitize_email($value);
													$value = "<a href='mailto:".antispambot($email,1)."'>".antispambot($value)."</a>";
												}?>
												<li> <span><?php echo esc_html($label);?> : </span> <?php echo ($value);?> </li><?php
											}
                                    	endfor;?>
                                    </ul><?php
                                endif;?>
                            </div>
                        </div>

						<?php echo !empty( $container_end ) ? $container_end : '';?>
                    </article><?php
                }
            }?>

            <!-- **Post Nav** -->
        	<div class="post-nav-container">
        		<div class="post-prev-link"><?php previous_post_link('%link','<i class="fa fa-caret-left"> </i> <span> '.__('Prev','designthemes-core').'</span>');?> </div>
        		<div class="post-next-link"><?php next_post_link('%link','<span>'.__('Next','designthemes-core').'</span> <i class="fa fa-caret-right"> </i>');?></div>
        	</div><!-- **Post Nav - End** -->
            

        	<?php
        		# Related Gallery
        		$related_post = cs_get_option('single-workout-related');
        		$terms = wp_get_object_terms( get_the_ID() ,'workout_entries' ,array('fields' => 'ids') );
        		if( $related_post && $terms ) :?>
        			<div class="dt-sc-hr-invisible"></div>
        			<div class="dt-sc-clear"></div>

        			<div class="related-galleries">
        				<h2><span><?php esc_html_e('Related Gallery','designthemes-core');?></span></h2><?php

        				$post_class = "workout column dt-sc-one-third";
        				$post_style = cs_get_option('single-workout-related-style');
						$design_hover_type = cs_get_option('single-workout-gallery-post-hover-design-type'); 
        				if( $show_sidebar ) {
        					$post_class = "workout column dt-sc-one-third with-sidebar";
        				}
        				$sc = "[dt_sc_workout_related_post post_class='".$post_class." ".$design_hover_type."' post_style='".$post_style."' id='".get_the_ID()."'/]";
        				echo do_shortcode($sc);?>
        			</div><?php
        		endif;

        		#Gallery Comments
	        	$post_comment = cs_get_option('single-workout-comments');
				if( $post_comment ):?>
    	            <div class="dt-sc-clear"></div>

        	        <!-- ** Comment Entries ** -->
            	    <section class="commententries">
                		<?php  comments_template('', true); ?>
                	</section><?php
                endif;
            ?>
        </section><!-- Primary End --><?php
		
		if ( $show_sidebar ) {
            if ( $show_left_sidebar ) {
                $sticky_class = ( array_key_exists('enable-sticky-sidebar', $settings) && $settings['enable-sticky-sidebar'] == 'true' ) ? ' sidebar-as-sticky' : '';?>
                
                <!-- Secondary Left -->
                <section id="secondary-left" class="secondary-sidebar <?php echo esc_attr( $sidebar_class.$sticky_class );?>"><?php
                	 fitnesszone_show_sidebar( 'dt_workouts', $post->ID, 'left' ); ?>
                </section><!-- Secondary Left End --><?php
            }
        }

        if ( $show_sidebar ) {
            if ( $show_right_sidebar ) {
                $sticky_class = ( array_key_exists('enable-sticky-sidebar', $settings) && $settings['enable-sticky-sidebar'] == 'true' ) ? ' sidebar-as-sticky' : '';?>

                <!-- Secondary Right -->
                <section id="secondary-right" class="secondary-sidebar <?php echo esc_attr( $sidebar_class.$sticky_class );?>"><?php
                	 fitnesszone_show_sidebar( 'dt_workouts', $post->ID, 'right' ); ?>
                </section><!-- Secondary Right End --><?php
            }
        }?>
    </div>
    <!-- ** Container End ** -->
    
</div><!-- **Main - End ** -->
<?php get_footer(); ?>