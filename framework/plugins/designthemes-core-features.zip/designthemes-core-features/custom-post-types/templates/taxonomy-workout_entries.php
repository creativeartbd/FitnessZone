<?php get_header();
    $global_breadcrumb = cs_get_option( 'show-breadcrumb' );
	$header_class	   = cs_get_option( 'breadcrumb-position' );
    $wtstyle = cs_get_option( 'wtitle-style' ); ?>
<!-- ** Header Wrapper ** -->
<div id="header-wrapper" class="<?php echo esc_attr($header_class); ?>">

    <!-- **Header** -->
    <header id="header">
        <div class="container"><?php
            /**
              * fitnesszone_header hook.
              * 
              * @hooked fitnesszone_vc_header_template - 10
              *
              */
            do_action( 'fitnesszone_header' ); ?>
      </div>
    </header><!-- **Header - End ** -->

    <!-- ** Breadcrumb ** -->
    <?php
        if( !empty( $global_breadcrumb ) ) {

            $bstyle = fitnesszone_cs_get_option( 'breadcrumb-style', 'default' );
            $style = fitnesszone_breadcrumb_css();

            $title = '<h1>'.get_the_archive_title().'</h1>';
            $breadcrumbs[] = __('Galleries','designthemes-core');
            $breadcrumbs[] = '<a href="'. get_category_link( get_query_var('gallery_entries') ) .'">' . single_cat_title('', false) . '</a>';

            $sub_title = esc_html__('Galleries Archive','designthemes-core');
            fitnesszone_breadcrumb_output ( $title, $breadcrumbs, $bstyle, $style, $sub_title );
        }
    ?><!-- ** Breadcrumb End ** -->                
</div><!-- ** Header Wrapper - End ** -->

<!-- **Main** -->
<div id="main">
    <!-- ** Container ** -->
    <div class="container"><?php
        $page_layout = cs_get_option( 'workout-archives-page-layout' );
        $page_layout  = !empty( $page_layout ) ? $page_layout : "content-full-width";

        $layout = fitnesszone_page_layout( $page_layout );
        extract( $layout );
        ?>

        <!-- Primary -->
        <section id="primary" class="<?php echo esc_attr( $page_layout );?>"><?php

        $page_layout = !empty($meta_set['layout']) ? $meta_set['layout'] : 'content-full-width';
        $post_layout = cs_get_option( 'workout-archives-post-layout' );
        $type = cs_get_option( 'workout-archives-post-style' );

		$article_class = "";
		$feature_image = "fitnesszone-blog-iii-column";
		$column = ""; $out = "";

		#Post layout check...
		switch($post_layout) {
			case "one-half-column":
				$article_class = "column dt-sc-one-half"; $feature_image = "fitnesszone-blog-ii-column"; $column = 2; break;

			case "one-third-column":
				$article_class = "column dt-sc-one-third"; $feature_image = "fitnesszone-blog-iii-column"; $column = 3; break;

			case "one-fourth-column":
				$article_class = "column dt-sc-one-fourth"; $feature_image = "fitnesszone-gallery-iv-column"; $column = 4; break;
		}


		#Better image size...
		switch($page_layout) {
			case "with-left-sidebar":
				$article_class = $article_class." with-sidebar";
				$feature_image = $feature_image."-sidebar";
				break;

			case "with-right-sidebar":
				$article_class = $article_class." with-sidebar";
				$feature_image = $feature_image."-sidebar";
				break;

			case "with-both-sidebar":
				$article_class = $article_class." with-sidebar";
				$feature_image = $feature_image."-bothsidebar";
				break;
		}

		#Selected categories...
		if(empty($categories)) {
			$cats = get_categories('taxonomy=workout_entries&hide_empty=1');
			$cats = get_terms( array('workout_entries'), array('fields' => 'ids'));
		} else {
			$cats = explode(',', $categories);
		}

		if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
		elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
		else { $paged = 1; }

		if(have_posts()): $i = 1;
		 while(have_posts()): the_post();

			$temp_class = "";

			if($i == 1) $temp_class = $article_class." first"; else $temp_class = $article_class;
			if($i == $column) $i = 1; else $i = $i + 1;

			$wmeta = get_post_meta(get_the_ID(), '_workout_settings', true);
			$out .= '<div class="'.$temp_class.'">';
				$out .= '<article id="post-'.get_the_ID().'" class="'.implode(" ", get_post_class("workout-entry", $post->ID)).'">';
				
					$out .= '<div class="dt-excersises '.$type.'">';
						$out .= '<div class="dt-excersise-thumb">';
							$out .= '<a href="'.get_permalink().'" title="'.get_the_title().'">';
								if(has_post_thumbnail()):
									$attr = array('title' => get_the_title(), 'alt' => get_the_title());
									$out .= get_the_post_thumbnail($post->ID, $feature_image, $attr);
								else:
									$out .= '<img src="http'.fitnesszone_ssl().'://placehold.it/1170X800.jpg&text='.get_the_title().'" alt="'.get_the_title().'" title="'.get_the_title().'" />';
								endif;
							$out .= '</a>';
						$out .= '</div>';
						$out .= '<div class="dt-excersise-detail">';
							$out .= '<div class="dt-excersise-detail-title">';
								if($type == 'type2'):
									if(!empty($wmeta['nosteps'])):
										$out .= '<p class="count">';
											$out .= '<a href="javascript:void(0)">'.$wmeta['nosteps'].' <br><span>'.__('Steps', 'designthemes-core').'</span></a>';
										$out .= '</p>';
									endif;
								endif;
									
								$out .= '<h5><a href="'.get_permalink().'">'.get_the_title().'</a></h5>';
								$out .= '<div class="dt-excersise-meta">';
								if($type == 'type1'):
									if(!empty($wmeta['nosteps'])):
										$out .= '<p class="count">';
											$out .= '<a href="javascript:void(0)">'.$wmeta['nosteps'].' <br><span>'.__('Steps', 'designthemes-core').'</span></a>';
										$out .= '</p>';
									endif;
								endif;
									if(!empty($wmeta['muscle_group']))
										$out .= '<h6>'.__('Muscle Group:', 'designthemes-core').'</h6><p>'.$wmeta['muscle_group'].'</p>';
										
										if($type == 'type2'):
											$out .= '<h6>'.__('Categories:', 'designthemes-core').'</h6>';
											$out .= '<p class="dt-excersise-meta">'.get_the_term_list(get_the_ID(), 'workout_entries', ' ', ', ', ' ').'</p>';
	
											if(!empty($wmeta['equipment']))
												$out .= '<h6>'.__('Equipment:', 'designthemes-core').'</h6><p class="dt-excersise-meta">'.$wmeta['equipment'].'</p>';
										
										$out .= '<a href="'.get_permalink().'" class="dt-sc-button small filled transforms3d"><span data-hover="'.__('View Exercise', 'designthemes-core').'">'.__('View Exercise', 'designthemes-core').'</span></a>';
										endif;
								$out .= '</div>';
							$out .= '</div>';
							if($type == 'type1'):
								$out .= '<div class="dt-excersise-detail-cnt">';
									$excerpt_length = !empty($excerpt_length) ? $excerpt_length : 25;
									$out .= fitnesszone_excerpt($excerpt_length);
								$out .= '</div>';
							endif;
						$out .= '</div>';
					$out .= '</div>';
				$out .= '</article>';
			$out .= '</div>';

		 endwhile;
		wp_reset_postdata();
		else:
			$out .= '<h2>'.__('Nothing Found.', 'designthemes-core').'</h2>';
			$out .= '<p>'.__('Apologies, but no results were found for the requested archive.', 'designthemes-core').'</p>';
        endif;
        
            echo "{$out}";
            ?>

    
        </section><!-- Primary End --><?php
		
		if ( $show_sidebar ) {
            if ( $show_left_sidebar ) {?>
                <!-- Secondary Left -->
                <section id="secondary-left" class="secondary-sidebar <?php echo esc_attr( $sidebar_class );?>"><?php
                    echo !empty( $wtstyle ) ? "<div class='{$wtstyle}'>" : '';

                    if( is_active_sidebar('custom-post-gallery-archives-sidebar-left') ):
                        dynamic_sidebar('custom-post-gallery-archives-sidebar-left');
                    endif;

                    $enable = cs_get_option( 'show-standard-left-sidebar-for-gallery-archives' );
                    if( $enable ):
                        if( is_active_sidebar('standard-sidebar-left') ):
                            dynamic_sidebar('standard-sidebar-left');
                        endif;
                    endif;

                    echo !empty( $wtstyle ) ? '</div>' : ''; ?>
                </section><!-- Secondary Left End --><?php
            }
        }

        if ( $show_sidebar ) {
            if ( $show_right_sidebar ) {?>
                <!-- Secondary Right -->
                <section id="secondary-right" class="secondary-sidebar <?php echo esc_attr( $sidebar_class );?>"><?php
                    echo !empty( $wtstyle ) ? "<div class='{$wtstyle}'>" : '';

                    if( is_active_sidebar('custom-post-gallery-archives-sidebar-right') ):
                        dynamic_sidebar('custom-post-gallery-archives-sidebar-right');
                    endif;

                    $enable = cs_get_option( 'show-standard-right-sidebar-for-gallery-archives' );
                    if( $enable ):
                        if( is_active_sidebar('standard-sidebar-right') ):
                            dynamic_sidebar('standard-sidebar-right');
                        endif;
                    endif;

                    echo !empty( $wtstyle ) ? '</div>' : ''; ?>
                </section><!-- Secondary Right End --><?php
            }
        }?>
    </div>
    <!-- ** Container End ** -->
</div><!-- **Main - End ** -->    
<?php get_footer(); ?>    