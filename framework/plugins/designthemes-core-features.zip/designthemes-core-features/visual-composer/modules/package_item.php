<?php add_action( 'vc_before_init', 'dt_sc_package_item_vc_map' );
function dt_sc_package_item_vc_map() {
	vc_map( array( 
		"name" => esc_html__( "Package Item", 'designthemes-core' ),
		"base" => "dt_sc_package_item",
		"icon" => "dt_sc_package_item",
		"category" => DT_VC_CATEGORY,		
		"params" => array(

			// Type
			array(
				'type'        => 'dropdown',
				'heading'     => esc_html__('Type', 'designthemes-core'),
				'param_name'  => 'type',
				'admin_label' => true,
				'value'       => array(
					  esc_html__('Default','designthemes-core') => 'default',
					  esc_html__('S2member','designthemes-core')  => 's2member',
				),
				'std' => 'standard'
		  ),

			// Heading
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Title", 'designthemes-core' ),
				'admin_label' => true,
      			"param_name" => "title"
      		),

			// Sub Title
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Sub title", 'designthemes-core' ),
				'admin_label' => true,
      			"param_name" => "subtitle"
      		),
			
			# Image url
			array(
				'type'       => 'attach_image',
				'heading'    => esc_html__('Image URL', 'designthemes-core'),
				'param_name' => 'image',
			),
			
			// Button Link
			array(
				'type' => 'vc_link',
				'heading' => esc_html__( 'URL (Link)', 'designthemes-core' ),
				'param_name' => 'button_link',
				'description' => esc_html__( 'Add link to button', 'designthemes-core' ),
			),	

			// Starting Price
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Starting Price", 'designthemes-core' ),
				"param_name" => "start_price",
				"edit_field_class" => "vc_column vc_col-sm-6",
      			"description" => esc_html__("Enter the starting price for this package e.g. 157",'designthemes-core'),
      			),


			// Start Duration
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Start Duration", 'designthemes-core' ),
				"param_name" => "start_duration",
				"edit_field_class" => "vc_column vc_col-sm-6",
      			"description" => esc_html__("Enter the start duration for this package e.g. 200",'designthemes-core'),
			  ),
			  
			  
			  //Start Day/Week/Month/Year
			  array(
				'type'        => 'dropdown',
				'heading'     => esc_html__('Start Day/Week/Month/Year', 'designthemes-core'),
				'param_name'  => 'start_dwmy',
				'admin_label' => true,
				'value'       => array(
					  esc_html__('Day','designthemes-core') => 'D',
					  esc_html__('Week','designthemes-core')  => 'W',
					  esc_html__('Month','designthemes-core')  => 'M',
					  esc_html__('Year','designthemes-core')  => 'Y',
				),
				'std' => 'D'
		  ),
		  
		  // Recurring Price
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Recurring Price", 'designthemes-core' ),
				"param_name" => "recurring_price",
				"edit_field_class" => "vc_column vc_col-sm-6",
      			"description" => esc_html__("Enter the recurring price for this package e.g. 157",'designthemes-core'),
      			),
			  
		  // Recurring Duration
      		array(
      			"type" => "textfield",
      			"heading" => esc_html__( "Recurring Duration", 'designthemes-core' ),
				"param_name" => "recurring_duration",
				"edit_field_class" => "vc_column vc_col-sm-6",
      			"description" => esc_html__("Enter the recurring duration for this package e.g. 200",'designthemes-core'),
			  ),
			
			//Recurring Day/Week/Month/Year
			  array(
				'type'        => 'dropdown',
				'heading'     => esc_html__('Start Day/Week/Month/Year', 'designthemes-core'),
				'param_name'  => 'recurring_dwmy',
				'admin_label' => true,
				'value'       => array(
					  esc_html__('Day','designthemes-core') => 'D',
					  esc_html__('Week','designthemes-core')  => 'W',
					  esc_html__('Month','designthemes-core')  => 'M',
					  esc_html__('Year','designthemes-core')  => 'Y',
				),
				'std' => 'D'
		  ),
		  
		  // Content
			
      		array(
      			'type' => 'textarea_html',
      			'heading' => esc_html__( 'Content', 'designthemes-core' ),
      			'param_name' => 'content',
				'value' => '<ul><li>Lorem ipsum dolor sit</li><li>Praesent convallis nibh</li><li>Nullam ac sapien sit</li><li>Phasellus auctor augue</li></ul>'
      		),
      		   		      		      					      		
		)
	) );
}?>