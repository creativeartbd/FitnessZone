<?php add_action( 'vc_before_init', 'dt_sc_contact_add1_vc_map' );
function dt_sc_contact_add1_vc_map() {
	vc_map( array(
		"name" => esc_html__("Slider Banner 1", 'designthemes-core'),
		"base" => "dt_sc_contact_add1",
		"icon" => "dt_sc_contact_add1",
		"category" => DT_VC_CATEGORY,
		"description" => esc_html__("Add different types of slider banner",'designthemes-core'),
		"params" => array(

			# Title
			array(
				'type' => 'textfield',
				'heading' => esc_html__('Title', 'designthemes-core'),
				'param_name' => 'title'
			),

			# link
			array(
				'type' => 'vc_link',
				'heading' => esc_html__('Link', 'designthemes-core'),
				'param_name' => 'link',
			),

			// Mid Text
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Mid Text', 'designthemes-core' ),
				'param_name' => 'mid_text',
				'description' => esc_html__( 'Enter Mid Text', 'designthemes-core' ),
				'admin_label' => true
			),

			// Offer Text
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Offer Text', 'designthemes-core' ),
				'param_name' => 'offer_text',
				'description' => esc_html__( 'Enter Offer Text', 'designthemes-core' ),
				'admin_label' => true
			),

			# Custom Icon
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Iconbox Image', 'designthemes-core' ),
				'param_name' => 'iconurl',
				'description' => esc_html__( 'Select image from media library', 'designthemes-core' ),
			),

			# Content
			array(
				'type' => 'textarea_html',
				'heading' => esc_html__('Content','designthemes-core'),
				'param_name' => 'content',
			),

		)
	) );	
}?>