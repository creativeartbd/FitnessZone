<?php add_action( 'vc_before_init', 'dt_sc_donutmorris_vc_map' );
function dt_sc_donutmorris_vc_map() {

	class WPBakeryShortCode_dt_sc_donutmorris extends WPBakeryShortCodesContainer {
	}

	vc_map( array(
		"name" => esc_html__( "Morris Donut Chart", 'designthemes-core' ),
		"base" => "dt_sc_donutmorris",
		"icon" => "dt_sc_donutmorris",
		"category" => DT_VC_CATEGORY,
		"content_element" => true,
		"js_view" => 'VcColumnView',
		'as_parent' => array( 'only' => 'dt_sc_morrislabel' ),
		'description' => esc_html__( 'Morris Donut Chart wrapper', 'designthemes-core' ),
		"params" => array(

					# Donut Color
					array(
						"type" => "colorpicker",
						"heading" => esc_html__( "Donut Color", 'designthemes-core' ),
						"param_name" => "color",
						'description' => esc_html__('Please select the color','designthemes-core')
					),
				  ),
		

			
			
		)
	 );
} ?>