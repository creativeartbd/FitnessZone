<?php add_action( 'vc_before_init', 'dt_sc_callout_box_vc_map' );
function dt_sc_callout_box_vc_map() {

	global $variations;

	vc_map( array(
            "name"     => esc_html__( "Call Out Box", 'designthemes-core' ),
            "base"     => "dt_sc_callout_box",
            "icon"     => "dt_sc_callout_box",
            "category" => DT_VC_CATEGORY,
            "params"   => array(
			
			
			# Type
			array(
				'type' => 'dropdown',
				'param_name' => 'type',
				'value' => array(
					esc_html__(' Type 1','designthemes-core') => 'type1',
					esc_html__(' Type 2','designthemes-core') => 'type2',
					esc_html__(' Type 3','designthemes-core') => 'type3',
					esc_html__(' Type 4','designthemes-core') => 'type4',
					esc_html__(' Type 5','designthemes-core') => 'type5',
				),
				'heading' => esc_html__( 'Type', 'designthemes-core' ),
				'description' => esc_html__( 'Select Callout type', 'designthemes-core' ),
			),
			
			# Title
      		array(
                        "type"       => "textfield",
                        "heading"    => esc_html__( "Title", 'designthemes-core' ),
                        "param_name" => "title"
      		),
			
			// Button Link
			array(
				'type' => 'vc_link',
				'heading' => esc_html__( 'URL (Link)', 'designthemes-core' ),
				'param_name' => 'link',
				'description' => esc_html__( 'Add link to button', 'designthemes-core' ),
				'dependency' => array( 'element' => 'type', 'value' =>'type2' ),
			),
			
			// Button Text
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Button Text', 'designthemes-core' ),
				'param_name' => 'button_text',
				'value' => esc_html__( 'Text on the button', 'designthemes-core' ),
				'dependency' => array( 'element' => 'type', 'value' =>'type2' ),
			),
			
		 // Custom Class
		  array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Custom class', 'designthemes-core' ),
				'param_name' => 'class',
				
		  ),
		  
		  # Type
			array(
				'type' => 'dropdown',
				'param_name' => 'align_content',
				'value' => array(
					esc_html__('Left','designthemes-core') => 'alignleft',
					esc_html__('Center','designthemes-core') => 'aligncenter',
					esc_html__('Right','designthemes-core') => 'alignright',
				),
				'heading' => esc_html__( 'Align Content', 'designthemes-core' ),
				'description' => esc_html__( 'Align Content section', 'designthemes-core' ),
			), 
		  
		  # Custom Image
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Image', 'designthemes-core' ),
				'param_name' => 'callout_image',
				'description' => esc_html__( 'Select image from media library', 'designthemes-core' ),
			),
		
		// Content
            array(
            	'type' => 'textarea_html',
            	'heading' => esc_html__('Content','designthemes-core'),
            	'param_name' => 'content',
            	'value' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at.'
            ), 
		  
		)
	) );
}?>