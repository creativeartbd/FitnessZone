<?php add_action( 'vc_before_init', 'dt_sc_contact_add2_vc_map' );
function dt_sc_contact_add2_vc_map() {
	vc_map( array(
		"name" => esc_html__("Slider Banner 2", 'designthemes-core'),
		"base" => "dt_sc_contact_add2",
		"icon" => "dt_sc_contact_add2",
		"category" => DT_VC_CATEGORY,
		"description" => esc_html__("Add different types of slider banner",'designthemes-core'),
		"params" => array(

			# Types
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Types', 'designthemes-core' ),
				'param_name' => 'type',
				'value' => array( 
							esc_html__('Type 1','designthemes-core')  => 'type1',
							esc_html__('Type 2','designthemes-core')  => 'type2',
				),
				'description' => esc_html__( 'Select banner type', 'designthemes-core' ),
				'std' => 'type1',
				'admin_label' => true
			),

			# link
			array(
				'type' => 'vc_link',
				'heading' => esc_html__('Link', 'designthemes-core'),
				'param_name' => 'link',
			),

			# Custom Icon
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Iconbox Image', 'designthemes-core' ),
				'param_name' => 'image',
				'description' => esc_html__( 'Select image from media library', 'designthemes-core' ),
			),

			// Button Text
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Button Text', 'designthemes-core' ),
				'param_name' => 'button_text',
				'description' => esc_html__( 'Enter Button Text', 'designthemes-core' ),
				'admin_label' => true
			),
		)
	) );	
}?>