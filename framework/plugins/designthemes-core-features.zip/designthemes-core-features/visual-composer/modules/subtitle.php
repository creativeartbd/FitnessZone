<?php add_action( 'vc_before_init', 'dt_sc_subtitle_vc_map' );
function dt_sc_subtitle_vc_map() {

	vc_map( array(
		"name" => esc_html__( "Sub Title", 'designthemes-core' ),
		"base" => 'dt_sc_subtitle',
		"icon" => 'dt_sc_subtitle',
		"category" => DT_VC_CATEGORY,
		"params" => array(
		
			# Sub Heading Tag
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Sub Heading tag','designthemes-core'),
				'param_name' => 'tag',
				'value' => array(
					'H1' => 'h1',
					'H2' => 'h2',
					'H3' => 'h3',
					'H4' => 'h4',
					'H5' => 'h5',
					'H6' => 'h6'
				),
				'std' => 'h2',
			),

			# Text
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Text', 'designthemes-core' ),
				'param_name' => 'title',
				'value' => 'Lorem ipsum dolor'
			),

			# Extra class name
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Extra class name', 'designthemes-core' ),
				'param_name' => 'class',
				'description' => esc_html__( 'Style particular element differently - add a class name and refer to it in custom CSS', 'designthemes-core' )
      		)			
		)
	) );
}?>