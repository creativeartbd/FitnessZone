<?php add_action( 'vc_before_init', 'dt_sc_callout_box_with_moving_bg_vc_map' );
function dt_sc_callout_box_with_moving_bg_vc_map() {

	global $variations;

	vc_map( array(
            "name"     => esc_html__( "Call Out Moving Bg", 'designthemes-core' ),
            "base"     => "dt_sc_callout_box_with_moving_bg",
            "icon"     => "dt_sc_callout_box_with_moving_bg",
            "category" => DT_VC_CATEGORY,
            "params"   => array(

		     		

      		# Custom Icon
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Image', 'designthemes-core' ),
				'param_name' => 'background_image_url',
				'description' => esc_html__( 'Select image from media library', 'designthemes-core' ),
			),

      		# Content
      		array(
      			'type' => 'textarea_html',
      			'heading' => esc_html__( 'Content', 'designthemes-core' ),
      			'param_name' => 'content',
      			'value' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>'
      		),

      		 # BG Color     
      	array(
			"type" => "colorpicker",
			"heading" => esc_html__( "Background color", 'designthemes-core' ),
			"param_name" => "bgcolor",
			"description" => esc_html__( "Select background color", 'designthemes-core' ),
      ),
		)
	) );
}?>