<?php add_action( 'vc_before_init', 'dt_sc_workout_plan_vc_map' );
function dt_sc_workout_plan_vc_map() {
	vc_map( array(
		"name" => esc_html__( "Workout Plan", 'designthemes-core' ),
		"base" => "dt_sc_workout_plan",
		"icon" => "dt_sc_workout_plan",
		"category" => DT_VC_CATEGORY,
		"params" => array(

			// Step Number
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Step Number', 'designthemes-core' ),
				'param_name' => 'step_no',
				'description' => esc_html__( 'Enter Step Number', 'designthemes-core' ),
				'admin_label' => true
			),

			// Steps Sup
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Steps Sup', 'designthemes-core' ),
				'param_name' => 'step_sup',
				'description' => esc_html__( 'Enter Steps Sup', 'designthemes-core' ),
				'admin_label' => true
			),

			// Step Name
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Step Name', 'designthemes-core' ),
				'param_name' => 'step_name',
				'description' => esc_html__( 'Enter Step Name', 'designthemes-core' ),
				'admin_label' => true
			),

			// Title
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', 'designthemes-core' ),
				'param_name' => 'title',
				'description' => esc_html__( 'Enter Title', 'designthemes-core' ),
				'admin_label' => true
			),

			# Link
			array(
				'type' => 'vc_link',
				'param_name' => 'link',
				'heading' => esc_html__( 'Link', 'designthemes-core' ),
			),

			// Content
            array(
            	'type' => 'textarea_html',
            	'heading' => esc_html__('Content','designthemes-core'),
            	'param_name' => 'content',
            	'value' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi hendrerit elit turpis, a porttitor tellus sollicitudin at.'
            ),
		)
	) );
}?>