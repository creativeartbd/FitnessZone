<?php add_action( 'vc_before_init', 'dt_sc_workouts_list_vc_map' );
function dt_sc_workouts_list_vc_map() {
	vc_map( array(
		"name" => esc_html__( "Workout Lists", 'designthemes-core' ),
		"base" => "dt_sc_workouts_list",
		"icon" => "dt_sc_workouts_list",
		"category" => DT_VC_CATEGORY,
		"params" => array(

			// Excerpt Length
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Excerpt Length', 'designthemes-core' ),
				'param_name' => 'excerpt_length',
				'description' => esc_html__( 'Enter Excerpt Length', 'designthemes-core' ),
				'value' => '25',
				'admin_label' => true
			),

			// Items limit
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Items Limit', 'designthemes-core' ),
				'param_name' => 'limit',
				'description' => esc_html__( 'Enter items limit', 'designthemes-core' ),
				'value' => '-1',
				'admin_label' => true
			),

			// Categories
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Categories', 'designthemes-core' ),
				'param_name' => 'categories',
				'description' => esc_html__( 'Enter category id separated by commas', 'designthemes-core' ),
				'admin_label' => true
			),

			// Post column
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Columns','designthemes-core'),
				'param_name' => 'posts_column',
				'value' => array(
					esc_html__('II Columns','designthemes-core') => 'one-half-column' ,
					esc_html__('III Columns','designthemes-core') => 'one-third-column',
					esc_html__('IV Columns','designthemes-core') => 'one-fourth-column',

				),
				'std' => 'one-third-column'
			),
			
			// Post column
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Type','designthemes-core'),
				'param_name' => 'type',
				'value' => array(
					esc_html__('Type 1','designthemes-core') => 'type1' ,
					esc_html__('Type 2','designthemes-core') => 'type2',

				),
				'std' => 'type1'
			),

		)
	) );
}?>