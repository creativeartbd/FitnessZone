<?php add_action( 'vc_before_init', 'dt_sc_morrislabel_vc_map' );
function dt_sc_morrislabel_vc_map() {

	class WPBakeryShortCode_dt_sc_morrislabel extends WPBakeryShortCode {
	}

	vc_map( array(
		"name" => esc_html__( "Morris Donut Labels", 'designthemes-core' ),
		"base" => "dt_sc_morrislabel",
		"icon" => "dt_sc_morrislabel",
		"category" => DT_VC_CATEGORY,
		'as_child' => array( 'only' => 'dt_sc_donutmorris' ),
		"params" => array(

     		# Morris List
			# Label
			array(
				"type" => "textfield",
				"heading" => esc_html__( "Label", 'designthemes-core' ),
				"param_name" => "label",
				'description' => esc_html__('Enter the Label','designthemes-core')
			),

			  # Value
			array(
				"type" => "textfield",
				"heading" => esc_html__( "Value", 'designthemes-core' ),
				"param_name" => "value",
				'description' => esc_html__('Enter the value','designthemes-core')
			)
			
		)
	) );
} ?>