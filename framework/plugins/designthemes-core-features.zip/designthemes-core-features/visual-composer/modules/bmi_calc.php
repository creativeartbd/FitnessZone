<?php add_action( 'vc_before_init', 'dt_sc_bmi_calc_vc_map' );
function dt_sc_bmi_calc_vc_map() {
	vc_map( array(
		"name" => esc_html__( "BMI Calculator", 'designthemes-core' ),
		"base" => "dt_sc_bmi_calc",
		"icon" => "dt_sc_bmi_calc",
		"category" => DT_VC_CATEGORY,
		"params" => array(

			// Post limit
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'View Link', 'designthemes-core' ),
				'param_name' => 'view_link',
				'description' => esc_html__( 'Enter view link', 'designthemes-core' ),
				'admin_label' => true
			),

		)
	) );
}?>