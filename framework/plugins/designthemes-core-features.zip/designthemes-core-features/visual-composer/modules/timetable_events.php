<?php add_action( 'vc_before_init', 'dt_sc_timetable_events_vc_map' );
function dt_sc_timetable_events_vc_map() {
	vc_map( array(
		"name" => esc_html__( "Timetable Events", 'designthemes-core' ),
		"base" => "dt_sc_timetable_events",
		"icon" => "dt_sc_timetable_events",
		"category" => DT_VC_CATEGORY .' ( '.esc_html__('Events','designthemes-core').')',
		"params" => array(
		
			
			// Event type
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Type','designthemes-core'),
				'param_name' => 'type',
				'value' => array(
					esc_html__('Type 1','designthemes-core') => 'type1', 
					esc_html__('Type 2','designthemes-core') => 'type2', 
				),
				'std' => 'type1'
			),

			// Limit
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Excerpt Length', 'designthemes-core' ),
				'param_name' => 'excerpt_length',
				'description' => esc_html__( 'Enter Excerpt Length', 'designthemes-core' )
			),
			
			// Limit
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Limit', 'designthemes-core' ),
				'param_name' => 'limit',
				'description' => esc_html__( 'Enter limit', 'designthemes-core' )
			),

			// Categories
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Categories', 'designthemes-core' ),
				'param_name' => 'categories',
				'description' => esc_html__( 'Enter categories', 'designthemes-core' )
			),	
			
			// Post column
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Columns','designthemes-core'),
				'param_name' => 'column',
				'value' => array(
					esc_html__('II Columns','designthemes-core') => 2 ,
					esc_html__('III Columns','designthemes-core') => 3,
					esc_html__('IV Columns','designthemes-core') => 4,

				),
				'std' => '3'
			),								
						
		)
	) );
}?>