<?php

#Update when order processing / complete...
add_action('woocommerce_order_status_completed', 'wc_gift_payment_complete');
add_action('woocommerce_order_status_processing', 'wc_gift_payment_complete');
if( !function_exists('wc_gift_payment_complete') ) {
function wc_gift_payment_complete($order_id) {
	
	$order = new WC_Order($order_id);
	$rname =  get_post_meta($order_id, '_gift_receiver_name', 1);
	$remail = get_post_meta($order_id, '_gift_receiver_email', 1);
	$rmsg = get_post_meta($order_id, '_gift_receiver_msg', 1);
	$email_tpl = cs_get_option('gcemail-template');
	$subject = cs_get_option('gcemail-subject');
	$customer = new WP_User(get_post_meta($order_id, '_customer_user', 1));
	$to = empty($remail) ? $order->billing_email : $remail;
	$message = str_replace('[receiver_name]', empty($rname) ? sprintf("%s %s", $order->billing_first_name, $order->billing_last_name) : $rname, $email_tpl);
	$coupons = $is_gift = '';
	
	foreach($order->get_items() as $item_id => $item)
	{
		$is_gift = get_post_meta($item['product_id'], '_gift', 1);
		if( $is_gift != 'yes' ) continue;

		$blogname = get_bloginfo();
		$giftname = $item['name'];
		$message = str_replace('[gift_name]', $giftname, $message);
		$message = str_replace('[blog_name]', $blogname, $message);
		$message = str_replace('[additional_message]', $rmsg, $message);
		$message = str_replace('[fname]', $order->billing_first_name, $message);
		$message = str_replace('[lname]', $order->billing_last_name, $message);		
	}
	if( $is_gift == 'yes' ) {

		$subject = $subject.' '.$order->billing_first_name;
		wp_mail($to,$subject, $message, array("From: $blogname <no-reply@nodomain.com>"));
	}
}
}
?>